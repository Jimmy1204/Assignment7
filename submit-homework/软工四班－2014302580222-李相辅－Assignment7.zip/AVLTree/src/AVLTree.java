import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;

/**
 * Created by coolautumn on 12/21/15.
 */
public class AVLTree implements IAVLTree
{
    Node root_Node;
    public boolean unBalance=false;
    public boolean shorter=false;

    public AVLTree()
    {
    }
    /*
     *private method of LRotation
     */
    private void LRotation(Node node)
    {
        Node[] child_node=node.getChildren();
        Node node0=child_node[0];
        Node node1=child_node[1];
        if(node0.getBalanceFactor()==1)
        {
            System.out.println("LL Rotation");

            node.setChild(node0.getChildren()[1],0);
            if(node0.getChildren()[1]!=null) {
                node0.getChildren()[1].setParent(node);
            }
            node0.setChild(node,1);
            if(node.getParent()!=null) {
                if (node.getId() < node.getParent().getId()) {
                    node0.setParent(node.getParent());
                    node.getParent().setChild(node0, 0);
                } else {
                    node.getParent().setChild(node0, 1);
                    node0.setParent(node.getParent());
                }

            }
            node.setParent(node0);
            node.setBalanceFactor(0);
            node0.setBalanceFactor(0);
            if(node.equals(root_Node))
            {
                root_Node=node0;
                root_Node.setParent(null);
            }
        }
        else
        {
            System.out.println("LR Rotation");

            //init
            Node childs_child_node=child_node[0].getChildren()[1];
            Node childs0=childs_child_node.getChildren()[0];
            Node childs1=childs_child_node.getChildren()[1];

            node.setChild(childs1,0);
            if(childs1!=null){
                childs1.setParent(node);
            }
            node0.setChild(childs0,1);
            if(childs1!=null) {
                childs0.setParent(node0);
            }

            if(node.getParent()!=null) {
                if (node.getParent().getId() > node.getId()) {
                    childs_child_node.setParent(node.getParent());
                    node.getParent().setChild(childs_child_node, 0);
                } else {
                    childs_child_node.setParent(node.getParent());
                    node.getParent().setChild(childs_child_node, 1);
                }
            }
            childs_child_node.setChild(node0,0);
            childs_child_node.setChild(node,1);
            node0.setParent(childs_child_node);
            node.setParent(childs_child_node);

            if(node.equals(root_Node))
            {
                root_Node=childs_child_node;
                root_Node.setParent(null);
            }

            switch (childs_child_node.getBalanceFactor()) {
                case 1:
                    node.setBalanceFactor(0);
                    node0.setBalanceFactor(-1);
                    childs_child_node.setBalanceFactor(0);
                    break;
                case -1:
                    node.setBalanceFactor(1);
                    node0.setBalanceFactor(0);
                    childs_child_node.setBalanceFactor(0);
                    break;
                case 0:
                    node.setBalanceFactor(0);
                    node0.setBalanceFactor(0);
                    childs_child_node.setBalanceFactor(0);
                    break;
            }

        }
        unBalance=false;
    }
    /*
     *private method of RRotation
     */
    private void RRotation(Node node)
    {
        Node[] child_node=node.getChildren();
        Node node1=child_node[1];
        Node node0=child_node[0];
        if(child_node[1].getBalanceFactor()==-1)
        {
            System.out.println("RR Rotation");


            node.setChild(child_node[1].getChildren()[0],1);
            node1.setChild(node,0);


            if(node.getParent()!=null) {
                if (node.getId() < node.getParent().getId()) {
                    node.getParent().setChild(node1, 0);

                } else {
                    node.getParent().setChild(node1, 1);
                }
                node1.setParent(node.getParent());

            }
            node.setParent(node1);
            node.setBalanceFactor(0);
            node1.setBalanceFactor(0);

            if(node.equals(root_Node))
            {
                root_Node=node1;
                root_Node.setParent(null);
            }
        }
        else
        {
            System.out.println("RL Rotation");

            //init
            Node childs_child_node=child_node[1].getChildren()[0];
            Node childs0=childs_child_node.getChildren()[0];
            Node childs1=childs_child_node.getChildren()[1];

            //child1 set the parent and child
            node1.setParent(childs_child_node);
            node1.setChild(childs1,0);
            if(childs1!=null) {
                childs1.setParent(node1);
            }

            node.setChild(childs0,1);
            if(childs0!=null) {
                childs0.setParent(node);
            }
            childs_child_node.setChild(node1,1);
            childs_child_node.setChild(node,0);



            if(node.getParent()!=null) {
                if (node.getParent().getId() > node.getId()) {
                    childs_child_node.setParent(node.getParent());
                    node.getParent().setChild(childs_child_node, 0);
                } else {
                    childs_child_node.setParent(node.getParent());
                    node.getParent().setChild(childs_child_node, 1);
                }
            }

            node.setParent(childs_child_node);
            if(node.equals(root_Node))
            {
                childs_child_node.setParent(null);
                root_Node=childs_child_node;
            }

            switch (childs_child_node.getBalanceFactor())
            {
                case 0:
                    node1.setBalanceFactor(0);
                    node.setBalanceFactor(0);
                    break;
                case 1:
                    node1.setBalanceFactor(-1);
                    node.setBalanceFactor(0);
                    break;
                case -1:
                    node1.setBalanceFactor(0);
                    node.setBalanceFactor(1);
                    break;
            }
            childs_child_node.setBalanceFactor(0);
        }
        unBalance=false;
    }
    /*
     *private insert method
     */
    private void p_insert(Node root,Node newNode)
    {
        if(root.getId()==newNode.getId()&&!unBalance)
        {
            System.out.println("Already present."+newNode.getData());
            return;
        }
        else if(root.getId()>newNode.getId())
        {
            if(root.getChildren()[0]==null)
            {
                newNode.setParent(root);
                root.getChildren()[0]=newNode;
                unBalance=true;
            }
            p_insert(root.getChildren()[0],newNode);
            if(unBalance)
            {
                switch (root.getBalanceFactor())
                {
                    case -1:
                        root.setBalanceFactor(0);
                        unBalance=false;
                        break;
                    case 0:
                        root.setBalanceFactor(1);
                        break;
                    case 1:
                        LRotation(root);
                        break;
                }
            }
        }
        else if(root.getId()<newNode.getId())
        {
            if(root.getChildren()[1]==null)
            {
                newNode.setParent(root);
                root.getChildren()[1]=newNode;
                unBalance=true;

            }
            p_insert(root.getChildren()[1],newNode);
            if(unBalance)
            {
                switch (root.getBalanceFactor())
                {
                    case 1:
                        root.setBalanceFactor(0);
                        unBalance=false;
                        break;
                    case 0:
                        root.setBalanceFactor(-1);
                        break;
                    case -1:
                        RRotation(root);
                        break;
                }
            }
        }

    }
    /*
     *private method of get
     */
    private Node p_get(Node root,int id)
    {
        Node[] nodes=root.getChildren();
        System.out.println(root.getId());
        if(root.getId()==id)        //find the correct node
        {
            return root;
        }
        else if(root.getId()>id)
        {
            if(nodes[0]==null)
            {
                return null;
            }
            else
            {
                return p_get(nodes[0],id);
            }
        }
        else if(root.getId()<id)
        {
            if(nodes[1]==null)
            {
                return null;
            }
            else
            {
                return p_get(nodes[1],id);
            }
        }
        return null;
    }
    /*
     *private method of checkBalance
     *
     */
    private void checkBalance_delete(Node node,int leftORright)
    {
        Node[] child_node=node.getChildren();
        if(shorter&&leftORright==0)
        {
            switch (node.getBalanceFactor())
            {
                case 1:
                    node.setBalanceFactor(0);
                    break;
                case 0:
                    node.setBalanceFactor(-1);
                    shorter=false;
                    break;
                case -1:
                    RRotation(node);
                    break;
            }
        }
        else if(shorter&&leftORright==1)
        {
            switch (node.getBalanceFactor()) {
                case -1:
                    node.setBalanceFactor(0);
                    break;
                case 0:
                    node.setBalanceFactor(1);
                    shorter = false;
                    break;
                case 1:
                    LRotation(node);
                    break;
            }
        }
        if(node.equals(root_Node))
        {
            return;
        }
        checkBalance_delete(node.getParent(),(node.getId()<node.getParent().getId()?0:1));
    }

    private void delete_node_with_LeftBranch(Node delete_node)
    {
        Node par=delete_node.getParent();
        /*  recognize the relationship    */
        Node node0=delete_node.getChildren()[0];
        if(node0!=null)
            node0.setParent(delete_node.getParent());
        if(delete_node.getParent()!=null) {
            delete_node.getParent().setChild(node0, 0);
        }
        else{
            delete_node.setChild(node0,0);
        }
            /*  now the delete_node has been kicked out the tree */


            /*
             *  change the bf of the parent of the delete_node
             *  check the balance of the tree
             */
        switch (delete_node.getParent().getBalanceFactor()) {
            case 1:
                shorter = true;
                if(par==null)
                {
                    return;
                }
                checkBalance_delete(par, 0);
                delete_node.getParent().setBalanceFactor(0);
                break;
            case 0:
                shorter = false;
                if(par==null)
                {
                    return;
                }
                checkBalance_delete(par, 0);
                delete_node.getParent().setBalanceFactor(-1);
                break;
            case -1:
                RRotation(delete_node.getParent());
                shorter = true;
                if(par==null)
                {
                    return;
                }
                checkBalance_delete(par, 0);

        }






/*
            //find the smaller leaf point
            Node smaller=getSmaller(delete_node.getChildren()[1]);
            if(smaller!=null)   System.out.println("smaller:"+smaller.getId());
            delete_node.setId(smaller.getId());

            if(par.getId()>delete_node.getId())
            {
                par.setChild(delete_node.getChildren()[0],0);
                delete_node.getChildren()[0].setParent(par);

                switch (b)
                {
                    case 1:
                        par.setBalanceFactor(0);
                        shorter=true;
                        break;
                    case 0:
                        par.setBalanceFactor(-1);
                        shorter=false;
                        break;
                    case -1:
                        RRotation(par);
                        break;
                }
                checkBalance_delete(par.getParent(), 0);
            }
            else
            {
                par.setChild(delete_node.getChildren()[0],1);
                delete_node.getChildren()[0].setParent(par);

                switch (b) {
                    case -1:
                        par.setBalanceFactor(0);
                        shorter = true;
                        break;
                    case 0:
                        par.setBalanceFactor(1);
                        shorter = false;
                        break;
                    case 1:
                        LRotation(par);
                        break;
                }

                checkBalance_delete(par.getParent(), 1);
            }
*/
    }

    private void delete_node_with_Nobranch(Node delete_node)
    {
        Node par=delete_node.getParent();
        int b=par.getBalanceFactor();

        if(par.getId()>delete_node.getId())
        {
            par.setChild(null,0);
            switch (b)
            {
                case 1:
                    shorter=true;
                    checkBalance_delete(par, (delete_node.getId()<par.getId()?0:1));
                    par.setBalanceFactor(0);
                    break;
                case 0:
                    par.setBalanceFactor(-1);
                    shorter=false;
                    break;
                case -1:
                    RRotation(par);
                    shorter=true;
                    checkBalance_delete(par, (delete_node.getId()<par.getId()?0:1));
                    break;
            }
        }
        else
        {
            par.setChild(null, 1);

            switch (b) {
                case -1:
                    checkBalance_delete(par, (delete_node.getId()<par.getId()?0:1));
                    shorter = true;
                    par.setBalanceFactor(0);
                    break;
                case 0:
                    shorter = false;
                    par.setBalanceFactor(1);
                    checkBalance_delete(par, (delete_node.getId()<par.getId()?0:1));
                    break;
                case 1:
                    LRotation(par);
                    shorter=true;
                    checkBalance_delete(par, (delete_node.getId()<par.getId()?0:1));
                    break;
            }
        }

    }

    private void delete_node_with_RightBranch(Node delete_node)
    {
        Node par=delete_node.getParent();

        /*  recognize the relationship    */
        Node node1=delete_node.getChildren()[1];
        if(node1!=null)
            node1.setParent(delete_node.getParent());
        delete_node.getParent().setChild(node1,(delete_node.getId()<delete_node.getParent().getId()?0:1));
        /*  now the delete_node has been kicked out the tree */

        /*
         *  change the bf of the parent of the delete_node
         *  check the balance of the tree
        */
        switch(delete_node.getParent().getBalanceFactor())
        {
            case -1:
                shorter=true;

                if(par==null)
                {
                    return;
                }
                checkBalance_delete(par, 1);
                delete_node.getParent().setBalanceFactor(0);
                break;
            case 0:
                shorter=false;

                if(par==null)
                {
                    return;
                }
                checkBalance_delete(par, 1);
                delete_node.getParent().setBalanceFactor(1);
                break;
            case 1:
                LRotation(delete_node.getParent());
                shorter=true;
                if(par==null)
                {
                    return;
                }
                checkBalance_delete(par, 1);
        }



/*
            Node larger=getLarger(delete_node.getChildren()[0]);
            delete_node.setId(larger.getId());

            if(par.getId()>delete_node.getId())
            {
                par.setChild(delete_node.getChildren()[1],0);
                delete_node.getChildren()[1].setParent(par);

                switch (b)
                {
                    case 1:
                        par.setBalanceFactor(0);
                        shorter=true;
                        break;
                    case 0:
                        par.setBalanceFactor(-1);
                        shorter=false;
                        break;
                    case -1:
                        RRotation(par);
                        break;
                }
                checkBalance_delete(par.getParent(), 0);
            }
            else
            {
                par.setChild(delete_node.getChildren()[1],1);
                delete_node.getChildren()[1].setParent(par);

                switch (b) {
                    case -1:
                        par.setBalanceFactor(0);
                        shorter = true;
                        break;
                    case 0:
                        par.setBalanceFactor(1);
                        shorter = false;
                        break;
                    case 1:
                        LRotation(par);
                        break;
                }

                checkBalance_delete(par.getParent(), 1);
            }
*/
    }
    /*
     *private method of delete
     */
    private void p_delete(int id)
    {
        Node delete_node=get(id);
        if(delete_node==null)
        {
            System.out.println("Not present.");
            return;
        }

        Node par=delete_node.getParent();

        if(delete_node.equals(root_Node)&&delete_node.getChildren()[0]==null&&delete_node.getChildren()[1]==null)
        {
            System.out.println("delete rootNode.");
            root_Node=null;
            return;
        }

        if (delete_node.getChildren()[0]==null&&delete_node.getChildren()[1]==null)
        {
            delete_after_anlyse(delete_node);
        }
        /*
         *the deleteNode only have left branch
         * only need to delete the current node and let its parent have his left child
         */
        else if(delete_node.getChildren()[1]==null)
        {
            /*
                find the smaller
                change the smaller's id with the delete_node
             */
            Node smaller=getSmaller(delete_node.getChildren()[0]);
            delete_node.setId(smaller.getId());
            delete_after_anlyse(smaller);
            delete_node.setData(smaller.getData());

        }
        else if(delete_node.getChildren()[0]==null)         //the deleteNode only have right branch
        {
            Node larger=getLarger(delete_node.getChildren()[1]);
            delete_node.setId(larger.getId());
            delete_after_anlyse(larger);
            delete_node.setData(larger.getData());
        }
        else
        {
            switch(delete_node.getBalanceFactor()) {
                case 0:

                case 1:
                    Node smaller = getSmaller(delete_node.getChildren()[0]);
                    delete_node.setId(smaller.getId());
                    delete_after_anlyse(smaller);
                    delete_node.setData(smaller.getData());

                    break;
                case -1:
                    Node larger=getLarger((delete_node.getChildren()[1]));
                    delete_node.setId(larger.getId());
                    delete_after_anlyse(larger);
                    delete_node.setData(larger.getData());


            }
        }
    }
    private void delete_after_anlyse(Node delete_node)
    {
        Node[] child_node=delete_node.getChildren();
        if(child_node[0]==null&&child_node[1]==null)
        {
            delete_node_with_Nobranch(delete_node);
        }
        else if(child_node[1]==null)
        {
            delete_node_with_LeftBranch(delete_node);
        }
        else
        {
            delete_node_with_RightBranch(delete_node);
        }
    }
    private Node getLarger(Node node)
    {
        if(node.getChildren()[0]!=null)
        {
            return getLarger(node.getChildren()[0]);
        }
        else
        {
            System.out.println("larger:"+node.getId());
            return node;
        }
    }
    private Node getSmaller(Node node)
    {
        if(node.getChildren()[1]!=null)
        {
            return getSmaller(node.getChildren()[1]);
        }
        else
        {
            System.out.println("smaller:"+node.getId());
            return node;
        }
    }
    @Override
    public Node get(int id) {
        return p_get(root_Node,id);
    }

    @Override
    public void insert(Node newNode) {
        unBalance=false;
        if(root_Node==null)
        {
            root_Node=newNode;
            return;
        }
        p_insert(root_Node,newNode);
    }

    @Override
    public void delete(int id) {
        shorter=false;
        p_delete(id);
    }

    private DefaultMutableTreeNode addTreeNode(DefaultMutableTreeNode treeNode,Node node)
    {
        String par0="",par1="";
        Node[] child_node=node.getChildren();
        if(child_node[0]!=null&&child_node[0].getParent()!=null)
        {
            par0=child_node[0].getParent().getId()+"";
        }
        if(child_node[1]!=null&&child_node[1].getParent()!=null)
        {
            par1=child_node[1].getParent().getId()+"";
        }
        if(node==null)
        {
            return null;
        }
        else
        {

            if(child_node[0]!=null) {
                System.out.println(child_node[0].getData());
                DefaultMutableTreeNode n1 = addTreeNode(new DefaultMutableTreeNode
                        (child_node[0].getData()+"-l  id:"+child_node[0].getId()
                                +"  bf:"
                                +child_node[0].getBalanceFactor()
                                +"  par:"
                                +par0), child_node[0]);
                if (n1 != null) treeNode.add(n1);
            }
            if(child_node[1]!=null) {
                System.out.println(child_node[1].getData());
                DefaultMutableTreeNode n2 = addTreeNode(new DefaultMutableTreeNode
                        (child_node[1].getData()+"-r  id:"+child_node[1].getId()
                                +"  bf:"
                                +child_node[1].getBalanceFactor()
                                +"  par:"
                                +par1), child_node[1]);
                if (n2 != null) treeNode.add(n2);
            }

        }
        return treeNode;
    }
    @Override
    public JTree printTree() {
        JFrame jFrame=new JFrame();
        JPanel jPanel=new JPanel();
        DefaultMutableTreeNode top=new DefaultMutableTreeNode
                (root_Node.getData()+"-top  id:"+root_Node.getId()+"  bf:"+root_Node.getBalanceFactor());
        System.out.println(root_Node.getData());
        top=addTreeNode(top,root_Node);
        JTree jTree=new JTree(top);

        jPanel.setLayout(new BorderLayout());
        jPanel.add(new JScrollPane(jTree));


        jFrame.add(jPanel);

        jFrame.setSize(500,600);
        jFrame.setLocation(400,100);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        return jTree;
    }
}
